#!/bin/sh
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "Android SDK pa jwenn. Louvri pwoje a nan Android Studio anvan."
  exit 1
fi
if [ -x ./gradlew ]; then
  ./gradlew assembleDebug
else
  echo "Gradle wrapper pa enkli. Nan Android Studio chwazi Build > Build APK(s)."
  exit 2
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
