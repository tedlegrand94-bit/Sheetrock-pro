@echo off
setlocal
if not exist "%ANDROID_HOME%" if not exist "%ANDROID_SDK_ROOT%" (
  echo Android SDK pa jwenn. Louvri pwoje a nan Android Studio anvan.
  exit /b 1
)
if exist gradlew.bat (
  call gradlew.bat assembleDebug
) else (
  echo Gradle wrapper pa enkli. Nan Android Studio chwazi Build ^> Build APK(s).
  exit /b 2
)
echo APK: app\build\outputs\apk\debug\app-debug.apk
