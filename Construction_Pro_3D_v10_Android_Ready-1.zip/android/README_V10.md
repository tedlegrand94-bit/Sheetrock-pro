# Construction Pro 3D — V10 Android

V10 se pwojè Android prepare pou Android Studio.

## Pou konstwi APK debug
1. Enstale Android Studio sou Windows/Mac/Linux.
2. Louvri **dosye `android`** sa a kòm pwojè.
3. Kite Android Studio enstale/telechaje Android SDK 35 ak zouti Gradle li mande yo.
4. Apre Gradle Sync fini: **Build → Build APK(s)**.
5. APK la ap nan `app/build/outputs/apk/debug/app-debug.apk`.

## Enstalasyon sou telefòn
Kopye `app-debug.apk` sou telefòn Android la, ouvri li, epi pèmèt enstalasyon nan sous Android mande a.

## Idantite app
- Non: Construction Pro 3D
- Package: com.constructionpro3d.app
- Version: 10.0
- Min Android: 6.0 (API 23)
- Target Android: 15 (API 35)

Pou Play Store pita, konstwi yon **signed AAB** ak Android Studio: Build → Generate Signed App Bundle / APK.
